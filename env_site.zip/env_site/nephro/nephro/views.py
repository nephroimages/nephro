from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
import firebase_admin
from firebase_admin import credentials, storage, firestore
from datetime import timedelta
# Initialize Firebase Admin SDK
cred = credentials.Certificate(r'C:\Users\chawk\env_site\nephro\flutter-app-55df2-firebase-adminsdk-j30so-eb545cbcbb.json')
firebase_admin.initialize_app(cred, {'storageBucket': 'flutter-app-55df2.appspot.com'})

from django.shortcuts import render

def home(request):
    try:
        bucket = storage.bucket()
        blobs = bucket.list_blobs(prefix='patients/')
        db = firestore.client()
        
        patient_data = {}
        for blob in blobs:
            path_parts = blob.name.split('/')
            if len(path_parts) >= 3:
                patient_id = path_parts[1]
                if patient_id not in patient_data:
                    patient_data[patient_id] = []
                
                # Generate a signed URL for each blob
                image_url = blob.generate_signed_url(timedelta(seconds=300), method='GET')
                patient_data[patient_id].append({
                    'blob_name': blob.name,
                    'url': image_url
                })
        
        # Update Firestore with the new status
        for patient_id, images in patient_data.items():
            images_ref = db.collection('patients').document(patient_id).collection('images')
            images_docs = images_ref.stream()
            
            for image_doc in images_docs:
                image_ref = images_ref.document(image_doc.id)
                image_ref.update({'status': 'analysis waiting to be completed'})
        
        formatted_data = [{'id': patient_id, 'images': [img['url'] for img in images]} for patient_id in patient_data]
        
        return render(request, "home.html", {"patients": formatted_data})
    except Exception as e:
        return HttpResponse(f"Error fetching images: {e}", status=500)



def get_image_url(request, image_name):
    try:
        bucket = storage.bucket()
        blob = bucket.blob(image_name)
        if not blob.exists():
            return HttpResponse(f"Blob {image_name} does not exist.", status=404)
        image_url = blob.generate_signed_url(timedelta(seconds=300), method='GET')
        return JsonResponse({"image_url": image_url})
    except Exception as e:
        return HttpResponse(f"Error generating URL for {image_name}: {e}", status=500)

# Static status simulation
STATUS_SIMULATION = {
    'image1': 'complete',
    'image2': 'pending',
    'image3': 'complete',
}

def check_analysis_status(request, image_id):
    status = STATUS_SIMULATION.get(image_id, 'pending')
    return JsonResponse({'status': status})

def update_image_status(request, patient_id):
    try:
        db = firestore.client()
        images_ref = db.collection('patients').document(patient_id).collection('images')
        images = images_ref.stream()

        for image in images:
            image_ref = images_ref.document(image.id)
            image_ref.update({'status': 'waiting for analysis to be completed'})

        return HttpResponse('Image statuses updated successfully.')
    except Exception as e:
        return HttpResponse(f"Error updating image statuses: {e}", status=500)

def update_image_status_single(patient_id, image_id):
    try:
        db = firestore.client()
        image_ref = db.collection('patients').document(patient_id).collection('images').document(image_id)
        image_ref.update({'status': 'waiting for analysis to be completed'})
    except Exception as e:
        return False
    return True

def upload_image(request, patient_id):
    if request.method == 'POST':
        try:
            image_file = request.FILES['image']
            file_name = image_file.name

            # Upload image to Firebase Storage
            bucket = storage.bucket()
            blob = bucket.blob(f'patients/{patient_id}/images/{file_name}')
            blob.upload_from_file(image_file)
            # Set blob to be publicly accessible
            blob.make_public()

            image_url = blob.public_url

            # Store image URL in Firestore
            db = firestore.client()
            image_ref = db.collection('patients').document(patient_id).collection('images').document()
            image_ref.set({
                'url': image_url,
                'fileName': file_name,
                'status': 'waiting for analysis to be completed',
            })

            return JsonResponse({'message': 'Image uploaded successfully', 'image_url': image_url})
        except Exception as e:
            return HttpResponse(f"Error uploading image: {e}", status=500)
    return HttpResponse(status=405)
